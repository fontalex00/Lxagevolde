
#include "danxincl.h"

// Global var
extern Body *bdp;
extern Exbd *exbd[NCORES];
std::mt19937 Mersrng(RNSEED);

//!-------------------------------------------------------------------
//! fctheader
//!-------------------------------------------------------------------
void Boundint(int *xl,int *xu,int bl,int bu) {

if(*xl < bl) *xl = bl;
if(*xu > bu) *xu = bu;

}

//!------------------------------------------------------------------
//! fctheader
//!------------------------------------------------------------------
float Bsigmoid(float x,float sl,float ts) {
   float res=(float)(1/(1+exp(-sl*(x-ts)))); return res;
}

//!------------------------------------------------------------------
//! fctheader
//!------------------------------------------------------------------
void set_fpu (unsigned int mode)
{
//asm ("fldcw %0" : : "m" (*&mode));
}

//!------------------------------------------------------------------
//! fctheader
//!------------------------------------------------------------------
int Intpower(int bb,int ee) {
int ii,res;

res=1; for(ii=0;ii<ee;ii++) res*=bb;
return res;
}

//!--------------------------------------------------------------------------
//! fctheader
//!--------------------------------------------------------------------------
void  Mysortxxxx(float par[],int szar,int opt,int ord[]) {
int   ii,jj,xii,*flags; float xval;
// opt=0: descending order,opt=1: ascending order

xval=0; xii=0; // to avoid warning
flags=(int *)malloc(sizeof(int)*szar);
for(ii=0;ii<szar;ii++) flags[ii]=YA;
for(ii=0;ii<szar;ii++) {
   if((ii%10000==0)&&(ii!=0)) printf("% d",ii);
   if(opt==0) { xval=-1; xii=0; } // max
   if(opt==1) { xval=+2; xii=0; } // min
   for(jj=0;jj<szar;jj++) {
      if(opt==0) if((xval<par[jj])&&(flags[jj]==YA)) { xval=par[jj]; xii=jj; }
      if(opt==1) if((xval>par[jj])&&(flags[jj]==YA)) { xval=par[jj]; xii=jj; }
   }
   ord[ii]=xii;
   flags[xii]=NO;
}
free(flags);
}

//!--------------------------------------------------------------------------
//! fctheader
//!--------------------------------------------------------------------------
int Compare (const void * a, const void * b) {
const Cgx *cga = (const Cgx *)a;
const Cgx *cgb = (const Cgx *)b;

if(cga->exord <cgb->exord) return -1;
if(cga->exord==cgb->exord) return  0;
if(cga->exord >cgb->exord) return  1;

return -1;
}

//!--------------------------------------------------------------------------
//! fctheader
//!--------------------------------------------------------------------------
/*void  Mysortxcgx(int thid,float par[],int szar,int opt,Cgx *cgardst,Cgx *cgarsrc) {
int   ci;
Exbd *edp=exbd[thid];

qsort (cgarsrc, szar, sizeof(Cgx), Compare);
memcpy(&cgardst[0],&cgarsrc[0],sizeof(Cgx)*szar);

}*/

//!--------------------------------------------------------------------------
//! fctheader
//!--------------------------------------------------------------------------
void  Mysortxcgx(int thid,float par[],int szar,int opt,Cgx *cgardst,Cgx *cgarsrc) {
int   ci;
Exbd *edp=exbd[thid];

for(ci=0;ci<szar;ci++) edp->ordaux[ci]=ci;
Mysortxxxx(&par[0],szar,opt,&edp->ordaux[0]);
for(ci=0;ci<szar;ci++)
   memcpy(&edp->cgaro[ci],&cgarsrc               [ci] ,sizeof(Cgx));
for(ci=0;ci<szar;ci++)
   memcpy(&cgardst   [ci],&edp->cgaro[edp->ordaux[ci]],sizeof(Cgx));
}

//!--------------------------------------------------------------------------
//! fctheader
//!--------------------------------------------------------------------------
void  Mysortlrxx(int thid,float par[],int szar,int opt,Clsr *drvard[],
                 Clsr *drvars[]) {
int   ii;
Exbd *edp=exbd[thid];

for(ii=0;ii<szar;ii++) edp->auxarr[ii]=ii;
Mysortxxxx(&par[0],szar,opt,&edp->auxarr[0]);
for(ii=0;ii<szar;ii++)
   memcpy(&drvard[ii],&drvars[edp->auxarr[ii]],sizeof(Clsr *));
}

//!--------------------------------------------------------------------------
//! fctheader
//!--------------------------------------------------------------------------
void  Gencpy(int gen1[],int gen0[],int b0,int ncopied)
{
if(gen0!=NULL) memcpy(&gen1[b0],&gen0[b0],sizeof(int)*ncopied);
else memset(&gen1[b0],0,sizeof(int)*ncopied);
}

//!--------------------------------------------------------------------------
//! fctheader
//!--------------------------------------------------------------------------
void  Leavexec(char * str) {
printf(str); printf("\n"); exit(1); }

//!--------------------------------------------------------------------------
//! fctheader
//!--------------------------------------------------------------------------
void  Cvint2base(int basear[],int *ndec0,int szar,int base,int *arind) {
int   ii,ndec;

// Least significant digit in last array position
*arind=*arind; // To avoid warnings
ndec=*ndec0;
for(ii=0;ii<szar;ii++) {
   basear[szar-1-ii]=ndec % base;
   ndec=ndec/base;
}
if(*arind!=-1) *arind+=szar;
}

//!--------------------------------------------------------------------------
//! fctheader
//!--------------------------------------------------------------------------
void Cvbase2int(int basear[],int *ndec0,int szar,int base,int *arind) {
int  ii;

// Least significant digit in last array position
*ndec0=0;
for(ii=0;ii<szar;ii++)
   // *ndec0+=(int)pow(base,ii)*basear[szar-1-ii];
   *ndec0+=(int)Intpower(base,ii)*basear[szar-1-ii];
if(*arind!=-1) *arind+=szar;
}

//!--------------------------------------------------------------------------
//! fctheader
//!--------------------------------------------------------------------------
void Cvbase2flt(int basear[],float *nflt0,int szar,int base,int *arind) {
int  ndec0; float maxval;

Cvbase2int(basear,&ndec0,szar,base,arind);
maxval=(float)Intpower(base,szar);
*nflt0=((ndec0/maxval)-(float)0.5)*2;
}

//!--------------------------------------------------------------------------
//! fctheader
//!--------------------------------------------------------------------------
void Varrescale(int *var,int scale0,int scale1) {
float fvar;

fvar=(float)*var;                   //fvar:   [0,scale0-1]
fvar=fvar/(float)(scale0-1);        //fvar:   [0,1]
// *var=(int)(fvar*(scale1-1));     //ivar:   [0,scale1-1]
fvar=fvar*(scale1-1);               //fvar:   [0,scale1-1]
// *var=floor(fvar+0.5);            //fvar:   [0,scale1-1] rounded
*var=(int)floor(fvar+0.5);          //fvar:   [0,scale1-1] rounded
}

//!------------------------------------------------------------------
//! fctheader
//!------------------------------------------------------------------
int Mocmatch(int *mos,int *moc,int asval) {
int ii,aa,bb,napos; 
// napos: nr of active positions

napos = 0;
bb = asval; if(bb<=1) bb = 1;
aa = bb-MOCRNG; if(aa<=0) aa = 0;
for(ii=aa;ii<bb;ii++) {
   if(moc[ii]!=0) napos++;
   if(moc[ii]!=0) if(mos[ii]!=moc[ii]) return NO;
}
if(napos>=1) return YA; 
else return NO;
}

//!------------------------------------------------------------------
//! fctheader
//!------------------------------------------------------------------
void Moccopy(int mocd[],int mocs[]) {
//for(int hi=0;hi<LFSPAN;hi++) mocd[hi] = mocs[hi];
memcpy(mocd,mocs,LFSPAN*sizeof(mocs[0]));
}

//!-------------------------------------------------------------------
//! fctheader
//!-------------------------------------------------------------------
void Printf4(FILE *fptr, const char *fmt, ...) {
va_list args;
char buffer[1024]; // Adjust the buffer size as needed

// Format the string using vsprintf
va_start(args, fmt);
vsprintf(buffer, fmt, args);
va_end(args);
// Print to stdout
printf("%s", buffer);
// Print to file pointer
fprintf(fptr, "%s", buffer);

}

//!------------------------------------------------------------------
//! fctheader
//!------------------------------------------------------------------
int Lreader(int par,Clsr *clp) {

if(par==Ldhn) return (int)clp->dhnrc3;
if(par==Ldrv) return (int)clp->drv;
if(par==Lcnd) return (int)clp->cnd;
if(par==Lcol) return (int)clp->col;

return -1;
}

//!------------------------------------------------------------------
//! fctheader
//!------------------------------------------------------------------
void Lwriter(int par,Clsr *clp,int dhnneu,int drvneu,int cndneu,int colneu) {

if(dhnneu!=-1) clp->dhnrc3=dhnneu;
if(drvneu!=-1) clp->drv   =drvneu;
if(cndneu!=-1) clp->cnd   =cndneu;
if(colneu!=-1) clp->col   =colneu;

}

//!-------------------------------------------------------------------
//! fctheader
//!-------------------------------------------------------------------
float Max3(float n0,float n1,float n2) {
float res;

res=(n0 >=n1) ? n0  : n1;
res=(res>=n2) ? res : n2;

return res;
}

//!------------------------------------------------------------------
//! fctheader
//!------------------------------------------------------------------
int Rnd1(int rnmax) {
std::uniform_int_distribution<int> distrib(0,rnmax-1);
return distrib(Mersrng);
}

//!------------------------------------------------------------------
//! fctheader
//!------------------------------------------------------------------
//int Rnd1(int rnmax) {
//return (int)(rnmax*(rand()/(RAND_MAX+1.0))); }

//!------------------------------------------------------------------
//! fctheader
//!------------------------------------------------------------------
float Sigmoid0(float xx,float ss) {
   float res=(float)(1/(1+exp(-ss*xx))-0.5); return res;
}

//!-------------------------------------------------------------------
//! function returns YA if cell is on shape's surface
//! function returns NO if cell is not on surface
//!-------------------------------------------------------------------
int Surfint(int x,int y,int z,Exbd *edp) {
int cnd,ii,a,b,c;

for(ii=0;ii<6;ii++) {
   if(ii==0) { a =-1; b = 0; c = 0; }
   if(ii==1) { a =+1; b = 0; c = 0; }
   if(ii==2) { a = 0; b =-1; c = 0; }
   if(ii==3) { a = 0; b =+1; c = 0; }
   if(ii==4) { a = 0; b = 0; c =-1; }
   if(ii==5) { a = 0; b = 0; c =+1; }
   cnd = Lreader(Lcnd,&edp->clar[x+a][y+b][z+c]);
   if((cnd != CLALIVE)&&(cnd != CLSLEEP)) return YA;   
}

return NO;
}

//!------------------------------------------------------------------
//! fctheader
//!------------------------------------------------------------------
void Setedges(Coord *el,Coord *eh,Coord ed[]) {

// coordinates : BACK
ed[0].x=el->x; ed[0].y=el->y; ed[0].z=el->z;//NW, B
ed[1].x=eh->x; ed[1].y=el->y; ed[1].z=el->z;//NE, B
ed[2].x=el->x; ed[2].y=eh->y; ed[2].z=el->z;//SW, B
ed[3].x=eh->x; ed[3].y=eh->y; ed[3].z=el->z;//SE, B
// coordinates : FRONT
ed[4].x=el->x; ed[4].y=el->y; ed[4].z=eh->z;//NW, F
ed[5].x=eh->x; ed[5].y=el->y; ed[5].z=eh->z;//NE, F
ed[6].x=el->x; ed[6].y=eh->y; ed[6].z=eh->z;//SW, F
ed[7].x=eh->x; ed[7].y=eh->y; ed[7].z=eh->z;//SE, F

}

//!------------------------------------------------------------------
//! fctheader
//!------------------------------------------------------------------
int Getthid(Exbd **edpp) {
int thid=0;

#if(MYMPI==1)
MPI_Comm_rank(MPI_COMM_WORLD,&thid);
#endif
*edpp=exbd[thid];

return thid;
}

//!------------------------------------------------------------------
//! fctheader
//!------------------------------------------------------------------
void Mpscpy(char *sndbuf, void *srcdat, int size, int *cnt) {

memcpy(sndbuf,srcdat,size); *cnt+=size;

}

//!------------------------------------------------------------------
//! fctheader
//!------------------------------------------------------------------
void Mprcpy(void *dstdat, char *recbuf, int size, int *cnt) {

memcpy(dstdat,recbuf,size); *cnt+=size;

}

#include <iostream> // to avoid codelite warnings
#include <fstream>  // to avoid codelite warnings
#include <string>   // to avoid codelite warnings
//!-------------------------------------------------------------------
//! fctheader
//!-------------------------------------------------------------------
void FileMerger() {
int openf = 0, opent = 0; // Initialize variables

std::ifstream filef(CONSFN); // first file
std::ifstream filet(CONSFT); // second file
if (!filef.is_open()) openf = 1;
if (!filet.is_open()) opent = 1;
if(openf == 1) std::cout << "filef error\n";
if(opent == 1) std::cout << "filet error\n";
std::ofstream mergedFile(CONSFA);
if (!mergedFile.is_open()) {
   std::cerr << "Error opening merged file\n";
}

std::string line;
if(openf == 0) {
   while (std::getline(filef, line))
      mergedFile << line << std::endl;
   filef.close(); // Close file after reading
}
if(opent == 0) {
   while (std::getline(filet, line))
      mergedFile << line << std::endl;
   filet.close(); // Close file after reading
}
mergedFile.close(); // Close merged file

}

