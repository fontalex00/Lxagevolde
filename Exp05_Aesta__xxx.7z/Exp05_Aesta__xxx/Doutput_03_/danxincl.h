
#include "danxparx.h"
// Include generic
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <malloc.h>
#include <string.h>
#include <stdarg.h>
#include <float.h>
#include <iostream> // std::cin, std::cout
#include <fstream>
#include <string>
#include <cstdio>
#include <Windows.h>
#include <random>
//#include <conio.h>  // HINT UNIX
#if(MYMPI==1)
#include <mpi.h>
#endif
// Include specific
#include "danxprot.h"

