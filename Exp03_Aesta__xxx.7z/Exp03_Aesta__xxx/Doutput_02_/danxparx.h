
#define _CRT_SECURE_NO_DEPRECATE
// Frequently modified 
#define RNSEED   902
#define MYMPI    1
#define NCORES   4
#define CYCLES   32000
#define SHOWSTEP 200
#define AMSGECOE 2.0
//#define PATHBASE "C:\\LocalCopies\\CodeProjects\\Canubage\\"
#define PATHBASE "D:\\Dropbox\\CodeProjects\\Canubage\\"
//#define PATHBLOC "C:\\LocalCopies\\CodeProjects\\Canubloc\\"
#define PATHBLOC "D:\\Droploc\\"
#define FOLDOUT "Doutput_02_"
#define COPYFILE CopyFile(CONSFA,CONSFT,FALSE);
//#define COPYFILE CopyFile((LPCWSTR)CONSFA,(LPCWSTR)CONSFT,FALSE);         

// Big options 
#define AGEFIT    1  // distributed weighted fitness
#define AGEMUT    1  // variable mutation rate
#define AGEFTM    0  // fixed timers
#define ISGRID    0    // DEF OPTION (loads initial grid status)
#define NICHEX   NO    // DEF OPTION
#define REMRED   NO    // DEF OPTION
#define ASON     YA    // DEF OPTION
#define MNETON   NO    // DEF OPTION
#define MOCDEV   YA

// Space and time related 
#define NDIMS     3    // no. of dimensions
#define COLORS   16
#define GRIDXX   38
#define GRIDYY  134
#define GRIDZZ   94
#define SZGRID   (GRIDXX*GRIDYY*GRIDZZ)
#define ZYGSSS   {19,67,21,1,1,1,25,27,11,25,27,11}
#define ZYGTOT   1
#define LFSPAN   28
#define MOCRNG   20 // range used in Mocmatch
#define GRACEP   2
// Shaping-related ----------------------------------------
#define NDQXXX   4 // normal to driver ratio
#define DOP2NS   3 // doper2 neighbourhood size
#define MS0MAX   3
#define DPLMAX   32 // questo parametro conta solo per DPVMAX!!! Vale frz[xqar[di]].dl !!
#define DPVMAX   ((2*DPLMAX)*(2*DPLMAX)*(2*DPLMAX)) // prolif. parallelepiped volume max
// Fitness related ----------------------------------------
#define FITEXP   2.5
#define FITTOL   2     // fitness tolerance
#define SHCOE0   1.00  // shad coef ([0-1] -> [b&w-color])
#define SHCOE2   0.50  // shad coef
#define FITMIX   0.00  // mix between shape and metabolism ([0-1] -> [shape-metabolism])
#define XSDS     4
#define YSDS     2
#define ZSDS     2
// xxxxxxxxxxxxxxx ----------------------------------------
#define CGARSZ   (20*LFSPAN)   // DVAR total elements #
#define DHARLS   6500
#define SMOCMA   4999
#define SMOCMB   9999
#define CGOKSZ   15
#define CGEVXX   15
#define NAPMIN   1
#define FSCMAX   0
#define HSTSTP   200
#define FITHST   250
#define GPSTEP   2
#define SHOWED   1
#define ZSTEPS   NO
//#define NSTEPS   10
#define VTKOPT   1
#define MNETSZ   6500
// Debug
#define DEBUG0   YA
#define DEBUG1   NO

// DVFREEZE -----------------------------------------------
#define NAMS     28   // number of age milestones
#define LSP LFSPAN-1  // last dev step
#define DGA CGARSZ  // abbreviation of CGARSZ
//      AMSGE  generat. e.p." (*)    IF      // (*) interval endpoint (1st=0)
//      AMSXF  frozen instructions"  THEN
//      AMSXE  instruction e.p." (*) IF/THEN // (*) interval endpoint (1st=0)
//      AMSLS  lower step            THEN
//      AMSUS  upper step            THEN
//      AMSDL  dpl max array         THEN
#define AMSGEA  0.3, 1.0, 2.0, 3.0, 4.0, 5.0, 6.0,
#define AMSXFA    0,   0,   0,   0,   0,   0,   0,
#define AMSXEA   80, 110, 140, 170, 200, 230, 260,
#define AMSLSA    0,   0,   0,   0,   0,   0,   0,
#define AMSUSA  LSP, LSP, LSP, LSP, LSP, LSP, LSP,
#define AMSDLA   12,  12,  12,  12,  12,  12,  12,
#define AMSFSA    0,   1,   2,   3,   4,   5,   6,
// xxxx
#define AMSGEB  7.0, 8.0, 9.0,10.0,11.0,12.0,13.0,
#define AMSXFB    0,   0,   0,   0,   0,   0,   0,
#define AMSXEB  290, 320, 350, 380, 410, 440, 470,
#define AMSLSB    0,   0,   0,   0,   0,   0,   0,
#define AMSUSB  LSP, LSP, LSP, LSP, LSP, LSP, LSP,
#define AMSDLB   10,  10,  10,  10,  10,  10,  10,
#define AMSFSB    7,   8,   9,  10,  11,  12,  13,
// xxxx
#define AMSGEC 14.0,15.0,16.0,17.0,18.0,19.0,20.0,
#define AMSXFC    0,   0,   0,   0,   0,   0,   0,
#define AMSXEC  500, 530, 560, DGA, DGA, DGA, DGA,
#define AMSLSC    0,   0,   0,   0,   0,   0,   0,
#define AMSUSC  LSP, LSP, LSP, LSP, LSP, LSP, LSP,
#define AMSDLC   10,  10,  10,  10,  10,  10,  10,
#define AMSFSC   14,  15,  16,  17,  17,  17,  17,
// xxxx
#define AMSGED 21.0,22.0,23.0,24.0,25.0,26.0,27.0
#define AMSXFD    0,   0,   0,   0,   0,   0,   0
#define AMSXED  DGA, DGA, DGA, DGA, DGA, DGA, DGA,
#define AMSLSD    0,   0,   0,   0,   0,   0,   0,
#define AMSUSD  LSP, LSP, LSP, LSP, LSP, LSP, LSP,
#define AMSDLD   10,  10,  10,  10,  10,  10,  10
#define AMSFSD   17,  17,  17,  17,  17,  17,  17
// xxxx
#define AMSGEX { AMSGEA AMSGEB AMSGEC AMSGED }
#define AMSXFX { AMSXFA AMSXFB AMSXFC AMSXFD }
#define AMSXEX { AMSXEA AMSXEB AMSXEC AMSXED }
#define AMSLSX { AMSLSA AMSLSB AMSLSC AMSLSD }
#define AMSUSX { AMSUSA AMSUSB AMSUSC AMSUSD }
#define AMSDLX { AMSDLA AMSDLB AMSDLC AMSDLD }
#define AMSFSX { AMSFSA AMSFSB AMSFSC AMSFSD }

// Files-input --------------------------------------------
#define CETISFN PATHBASE "Dinputx\\bodddd0_ooooooooo_voxgr.txt"
#define  CDISFN PATHBASE "Dinputx\\boeeee0_ooooooooo_voxgr.txt"
#define  CDTGFN PATHBASE "Dinputx\\aaanubi_038134094_voxgr.txt"
#define  MNTGFN PATHBASE "Dinputx\\aaanubi_038134094_xmnet.txt"
#define    HCFN PATHBASE "Dinputx\\bxcgar2.txt"
// Files-output -------------------------------------------
#define  CONSFN PATHBASE FOLDOUT "\\bxconsole.txt"
#define  CONSFA PATHBASE FOLDOUT "\\bxconsall.txt"
#define  CONSFT PATHBASE FOLDOUT "\\bxconstmp.txt"
#define  HSTXFN PATHBASE FOLDOUT "\\bxhst.txt"
#define  GENXFN PATHBASE FOLDOUT "\\bxgen.txt"
#define  CGARFN PATHBASE FOLDOUT "\\bxcgar.txt"
#define  DHLSFN PATHBASE FOLDOUT "\\bxdhls.txt"
#define OUTDIRN PATHBLOC FOLDOUT "Aux"
#define VTKFILE PATHBLOC FOLDOUT "Aux\\exvtkfn"
#define GRDFILE PATHBLOC FOLDOUT "Aux\\exgrdfn"
#define MNET0FN PATHBLOC FOLDOUT "Aux\\hxmnet0.txt"
#define MNET1FN PATHBLOC FOLDOUT "Aux\\hxmnet1.txt"
#define MNET2FN PATHBLOC FOLDOUT "Aux\\hxmnet2.txt"
// I/O DEBUG
#define XDBG0FN PATHBASE FOLDOUT "\\exdbg0.txt"
#define XDISTFN PATHBASE FOLDOUT "\\exdst0.txt"
#define XRORDFN PATHBASE FOLDOUT "\\exrord.txt"
#define XSUSPFN PATHBASE FOLDOUT "\\xxsusp.txt"

// Mnet ---------------------------------------------------
#define OXARSZ   16 // expression list size
#define SZSUSP    8
#define MAXIPS    2
#define LAYERS    3
#define SIGMA1    4
#define THRESHA   ((float)0.5)
#define OXRCHD    3
#define IPARSZ    4
#define OPARSZ    4
#define MXARSZ    4
#define EXARSZ   10
// Mnet_End -----------------------------------------------

// Variables' size in the Genome --------------------------
// Instructions, left  part -------------------------------
#define OPXXSQ    5 //order of precedence field
#define ASXXSQ    3 //age step            field
#define CETXSQ    7 //CET                 field
// Instructions, right part -------------------------------
#define DPLXSQ    4 //displacement        field
#define MS0XSQ    1 //master switch       field
#define MS1XSQ    1 //master switch       field
#define DGDXSQ    3 //diagonal distance   field
#define COLXSQ    2 //color number        field
#define OLRXSQ    2 //outside lr          field
#define SUFXSQ    1 //subst. filter       field
#define XCHXSQ    3 //changed oxr's       field
// Totals -------------------------------------------------
#define CGSXQ0    (1+OPXXSQ+ASXXSQ+1+(CETXSQ*LFSPAN)+LFSPAN)
#define CGSAQ1    ((6*DPLXSQ)+MS0XSQ+MS1XSQ+(9*DGDXSQ)+COLXSQ+COLXSQ)
#define CGSBQ1    (OLRXSQ+SZSUSP+SZSUSP+(OXRCHD*XCHXSQ))
#define CGSXQ1    (CGSAQ1+CGSBQ1)
#define CGOXSQ    (CGSXQ0+CGSXQ1)
#define CGARSQ    (CGOXSQ*CGARSZ)          // CGAR total bases
// Exp structure ------------------------------------------
#define LRXXSQ    1 // layer
#define SIXXSQ    2 // subst. identifier
#define WHTXSQ    2 // function
#define OXRXSQ    (1+LRXXSQ+(MAXIPS*SIXXSQ)+((MAXIPS+1)*WHTXSQ)+SIXXSQ)
#define OXARSQ    (OXRXSQ*OXARSZ)

// GA -----------------------------------------------------
#define NPOPS     1 //12
#define GNHSZ     3 // gen header size
//#define GENXSZ  (GNHSZ+CGARSQ)
#define GENXSZ    (GNHSZ+CGARSQ+OXARSQ)
#define PCROSS    0.5
//#define PMUTAT    0.5
#define MPCMUT    0.005
#define ATPMAX    60
#define POPSZ0    144
#define POPSZ1    0
#define POPXSZ    (POPSZ0+POPSZ1)
#define NKIDS0    144  // CND: POPSZ0 > NKIDS0+NKIDS1
#define NKIDS1    0
#define NICHESS   1
#define NICHEA    2
#define NNGUYS    NPOPS*POPXSZ

// LABELS & abbreviations ---------------------------------
#define NO        0
#define YA        1
#define opened    {
#define closed    }
// Cells
#define CLNOCEL   1
#define CLNOCL0   2
#define CLALIVE   3
#define CLSLEEP   4
#define CLUNDEF  -1
// xxxx
#define Ldhn      0
#define Ldrv      1
#define Lcnd      2
#define Lcol      3
#define Lxxx      4
#define FORVXYZ   for(vx=0;vx<GRIDXX;vx++) for(vy=0;vy<GRIDYY;vy++) for(vz=0;vz<GRIDZZ;vz++)
#define sizeof_gen_ (sizeof(int)*GENXSZ)
#define sizeofcgar0 (sizeof(Cgx)*edp->cgarsz)
#define sizeofdharf (sizeof(Cge)*DHARLS)
#define FORGRDCYC(x,y,z,lx,ly,lz,ux,uy,uz) \
   for(x=lx;x<=ux;x++) \
   for(y=ly;y<=uy;y++) \
   for(z=lz;z<=uz;z++) 


